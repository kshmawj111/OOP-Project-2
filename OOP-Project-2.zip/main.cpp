#include <stdio.h>
#include "inf_int.h"

using namespace std;

int main()
{
	while (1) {
		Expression exp;
		string new_exp = exp.get_exp();
		cout << "input expression: " << exp.expression << endl;
		exp.to_postfix(new_exp);
		cout << "postfix expression: " << exp.expression << endl;
		inf_int temp = exp.eval();

		cout << temp << endl;
	}
}